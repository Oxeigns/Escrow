# Escrow Bot Ultimate

A production-ready Telegram escrow bot with:
- Webhook or Polling (switch by env)
- MongoDB (Motor) data store
- Blacklist/scammer logic
- Buyer/Seller guided forms
- Admin panel (CLI)
- MarkdownV2 + HTML safe rendering
- Docker + Render deployment
- Webhook cleanup when switching to polling

See `escrow_bot_codex_instructions.txt` for a Codex-style setup guide.
